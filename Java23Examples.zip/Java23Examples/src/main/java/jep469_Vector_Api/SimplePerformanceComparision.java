package jep469_Vector_Api;

import jdk.incubator.vector.DoubleVector;
import jdk.incubator.vector.VectorSpecies;

import java.util.stream.DoubleStream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class SimplePerformanceComparision
{
    record Result(double[] resultToIgnore, long runningTime) {};

    public static void main(final String[] args)
    {
        // 1_000_000 => scalar faster
        for (int size : new int[]{10_000, 1_000_000, 50_000_000, 500_000_000}) {

            System.out.println("Mearsuring size: " + size);
            System.out.println("---------------------------");

            double[] values1 = DoubleStream.iterate(1, i -> i + 1).limit(size).toArray();
            double[] values2 = DoubleStream.iterate(1, i -> i + 1).limit(size).toArray();

            int MEASURE_LOOPS = 10;
            long summedTime1 = 0;
            for (int i = 0; i < MEASURE_LOOPS; i++) {
                Result result1 = measureScalar(i, values1, values2);
                summedTime1 += result1.runningTime;
            }

            long summedTime2 = 0;
            for (int i = 0; i < MEASURE_LOOPS; i++) {
                Result result2 = measureVector(i, values1, values2);
                summedTime2 += result2.runningTime;
            }

            System.out.println("RESULT " + size);
            System.out.println("SCALAR AVG duration (ns)\t" + (summedTime1 / MEASURE_LOOPS));
            System.out.println("VECTOR AVG duration (ns)\t" + (summedTime2 / MEASURE_LOOPS));
        }
    }

    static private Result measureScalar(int iteration, double[] input1, double[] input2) {
        double[] output = new double[input1.length];
        long start = System.nanoTime();
        for (int i = 0; i < input1.length; ++i) {
            output[i] = Math.sqrt(input1[i] * input1[i] + input2[i] + input2[i]) +
                    Math.sqrt(input1[i] * input1[i] - input2[i] + input2[i]);
        }
        long finish = System.nanoTime();
        System.out.println(iteration + "\t scalar duration (ns)\t" + (finish - start));
        return new Result(output, finish - start);
    }

    static private Result measureVector(int iteration, double[] input1, double[] input2) {
        final VectorSpecies<Double> SPECIES = DoubleVector.SPECIES_PREFERRED;

        double[] output = new double[input1.length];
        long start = System.nanoTime();
        for (int i = 0; i < SPECIES.loopBound(input1.length); i += SPECIES.length()) {
            DoubleVector va = DoubleVector.fromArray(SPECIES, input1, i);
            DoubleVector vb = DoubleVector.fromArray(SPECIES, input2, i);
            DoubleVector vc = va.mul(va).add(vb.mul(vb)).sqrt().add(va.mul(va).sub(vb.mul(vb)).sqrt());
            vc.intoArray(output, i);
        }
        // Hier fehlt eigentlich noch eine andere Schleife
        long finish = System.nanoTime();
        System.out.println(iteration + "\t vector duration (ns)\t" + (finish - start));
        return new Result(output, finish - start);

    }
}
