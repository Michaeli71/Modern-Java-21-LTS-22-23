package jep480_Structured_Concurrency;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.function.Function;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class StructuredConcurrencOwnTaskScopeExample {
    public static void main(final String[] args) throws ExecutionException, InterruptedException {
        structuredConcurrencyShutdownOnSuccess();
    }

    record NetworkConnection(String type) {
    }

    public static void structuredConcurrencyShutdownOnSuccess() throws ExecutionException, InterruptedException {
        //try (var scope = new FirstNSuccessful<NetworkConnection>(2))
        try (var scope = new FirstNSuccessful<NetworkConnection>(2)) {
            var result1 = scope.fork(() -> tryToGetWifi());
            var result2 = scope.fork(() -> tryToGet5g());
            var result3 = scope.fork(() -> tryToGet4g());
            var result4 = scope.fork(() -> tryToGet3g());
            var result5 = scope.fork(() -> tryToGet2gEdge());
            scope.join();

            // trying to access with get()
            // System.out.println("" + result1.get() + "/" + result2.get() + "/" + result3.get() + "/" + result4.get());
            // results in:
            // Exception in thread "main" java.lang.IllegalStateException: Result is unavailable or subtask did not complete successfully
            //	at java.base/java.util.concurrent.StructuredTaskScope$SubtaskImpl.get(StructuredTaskScope.java:939)
            System.out.println("found connection: " + scope.result());
        }
    }

    private static NetworkConnection tryToGet3g() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new NetworkConnection("3G");
    }

    private static void sleepRandomlyUpToOneSec() throws InterruptedException {
        Thread.sleep((long) (1000 * Math.random()));
    }

    private static NetworkConnection tryToGet4g() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new NetworkConnection("4G");
    }

    private static NetworkConnection tryToGet5g() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new NetworkConnection("5G");
    }

    private static NetworkConnection tryToGetWifi() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new NetworkConnection("Wifi");
    }

    private static NetworkConnection tryToGet2gEdge() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new NetworkConnection("2G (Edge)");
    }


    // Für Java-Profi
    public static final class FirstNSuccessful<T> extends StructuredTaskScope<T> {
        private int maxResults = 0;

        private volatile List<T> firstResults = new CopyOnWriteArrayList<>();
        private volatile Throwable lastException = null;

        public FirstNSuccessful(int n, String name, ThreadFactory factory) {
            super(name, factory);
            this.maxResults = n;
        }

        /**
         * Constructs a new unnamed {@code ShutdownOnSuccess} that creates virtual threads.
         *
         * @implSpec This constructor is equivalent to invoking the 2-arg constructor with
         * a name of {@code null} and a thread factory that creates virtual threads.
         */
        public FirstNSuccessful(int n) {
            this(n, null, Thread.ofVirtual().factory());
        }

        @Override
        protected void handleComplete(Subtask<? extends T> subtask) {
            if (firstResults.size() > maxResults) {
                // already captured a result
                return;
            }

            if (subtask.state() == Subtask.State.SUCCESS) {
                // task succeeded
                T result = subtask.get();
                firstResults.add(result);
                if (firstResults.size() == maxResults) {
                    super.shutdown();
                }
            }
            if (subtask.state() == Subtask.State.FAILED) {
                System.out.println("Some errors occurred");
                lastException = subtask.exception();
            }
        }

        @Override
        public FirstNSuccessful<T> join() throws InterruptedException {
            super.join();
            return this;
        }

        @Override
        public FirstNSuccessful<T> joinUntil(Instant deadline)
                throws InterruptedException, TimeoutException {
            super.joinUntil(deadline);
            return this;
        }

        public List<T> result() throws ExecutionException {
            return result(ExecutionException::new);
        }

        public <X extends Throwable> List<T> result(Function<Throwable, ? extends X> esf) throws X {
            Objects.requireNonNull(esf);
            ensureOwnerAndJoined();

            if (firstResults.size() > 0)
                return firstResults;

            Throwable exception = lastException;
            if (exception != null) {
                X ex = esf.apply(exception);
                Objects.requireNonNull(ex, "esf returned null");
                throw ex;
            }

            throw new IllegalStateException("No completed subtasks");
        }
    }

}