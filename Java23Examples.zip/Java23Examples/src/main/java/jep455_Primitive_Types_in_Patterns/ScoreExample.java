package jep455_Primitive_Types_in_Patterns;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class ScoreExample {
    void evaluate(final int score) {
        var result = switch (score) {
            case int value when value > 100 -> "DISQUALIFIED due to cheting";
            case int value when value >= 80 -> "excellent";
            case int value when value >= 50 -> "okaish";
            case int value when value >= 0 && value <= 50 -> "below expectations";
            default -> throw new IllegalStateException("Invalid score: " + score);
        };
        System.out.println("Your score: " + result);
    }
}
