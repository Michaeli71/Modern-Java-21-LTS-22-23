package jep477_Implicitly_Declared_Classes;

public class Point {
}
