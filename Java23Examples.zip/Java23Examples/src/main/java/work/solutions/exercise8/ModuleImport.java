package work.solutions.exercise8;

import module java.base;
import module java.desktop;

// needed to solve ambiguity
import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class ModuleImport {
    public static void main(String[] args) {
        List<String>  drinks = Stream.of("apple juice", "beer", "tee",
                "water", "milk", "coffee").toList();
        var mapping = categorizeToFirstLetter(drinks);

        IO.println("Mapping of " + LocalDate.now() + ": " + mapping);
        performUiStuff(mapping);
    }

    private static Map<String, String> categorizeToFirstLetter(List<String> values) {
        return values.stream().collect(Collectors.toMap(toUpperFirstChar(), Function.identity()));
    }

    private static Function<String, String> toUpperFirstChar() {
        return str -> str.toUpperCase().substring(0, 1);
    }

    private static void performUiStuff(Map<String, String> mapping) {
        JOptionPane.showMessageDialog(null, "Mapping of " + LocalDate.now() + ": " + mapping);

        Toolkit.getDefaultToolkit().beep();
        JOptionPane optionPane = new JOptionPane(mapping, JOptionPane.WARNING_MESSAGE);
        JDialog dialog = optionPane.createDialog("Mapping of " + LocalDate.now());
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
    }
}
