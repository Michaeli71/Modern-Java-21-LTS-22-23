package work.exercises.exercise7;

import java.util.List;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class FindTemperatureJumps {
    public static void main(String[] args) {

        // Find temperature jumps of over 20 degrees
        var temps = Stream.of(0, 10, 7, 20, 25, 12, 17, 40, 10, 20, 42, 30).
                // gather(/* TODO */).
                // filter(/* TODO */).
                toList();

        System.out.println("temp jumps: " + temps);
    }
}
