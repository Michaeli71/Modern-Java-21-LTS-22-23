package work.exercises.exercise7;

import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class CollectCoordinates {
    public static void main(String[] args) {
        record Point3d(int x, int y, int z) {
            /* TODO BONUS */
        }

        var coordinates = Stream.of(0, 0, 0, 10, 20, 30, 100, 200, 300,
                                   1000, 2000, 3000);
                                 /* gather(null) TODO*/
                                 /* TODO */;
        System.out.println("coordinates: " + coordinates);
    }
}
