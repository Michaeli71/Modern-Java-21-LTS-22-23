import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

import static java.lang.Math.round;

public class IntValuesTest {


    @Test
void notMatchingStatistics()
{
    var nonMatchingCount = new AtomicInteger();
    var matchingCount = new AtomicInteger();

    // bis 10_000_000 => keine Abweichung
    int MIN = -10_000_000;
    int MAX = 50_000_000;
    IntStream.range(MIN, MAX).forEach(i -> {
        float floatValue = i;

        int floatValueAsInt = (int) floatValue;

        if (i != floatValueAsInt) {
            nonMatchingCount.incrementAndGet();
        } else {
            matchingCount.incrementAndGet();
        }
    });

    printStatistics(nonMatchingCount, matchingCount, MAX, MIN);
}

private static void printStatistics(AtomicInteger nonMatchingCount,
                                    AtomicInteger matchingCount,
                                    int MAX, int MIN)
{
    System.out.println("float/int values");
    System.out.println("non matching: " + nonMatchingCount.get());
    System.out.println("    matching: " + matchingCount.get());
    System.out.println("       total: " + (matchingCount.get() + nonMatchingCount.get()));

    System.out.println("in %");
    System.out.println("non matching %: " + (Math.round(100.00d / (MAX - MIN) * nonMatchingCount.get())));
    System.out.println("    matching %: " + (Math.round(100.00d / (MAX - MIN) * matchingCount.get())));
}
}
